﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalDB
{
    public partial class Form2 : Form
    {
        private DBHospitalEntity dom = new DBHospitalEntity();
        Form1 form1;
        public Form2()
        {
            InitializeComponent();
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = dom.Patients.Select(p => new {p.PatientId,p.PatientName,p.Address,p.Contact,p.DoctorId  }).ToList();


        }

        private void insertbtn_Click(object sender, EventArgs e)
        {
            Patient patient = new Patient();
            patient.PatientName =txtpname.Text;
            patient.Address=txtpaddress.Text;
            patient.Contact = Convert.ToInt32(txtpcontact.Text);
            patient.DoctorId= Convert.ToInt32(txtdid.Text);

            dom.Patients.Add(patient);
            dom.SaveChanges();
            //Form1_Load(dom, e);

            Form2 form2 = new Form2();
            form2.Show();
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            int pateintid = Convert.ToInt32(txtpid.Text);

            Patient p = dom.Patients.Find(pateintid);
            p.PatientName = txtpname.Text;
            p.Address = txtpaddress.Text;
            p.Contact = Convert.ToInt32(txtpcontact.Text);
            p.DoctorId = Convert.ToInt32(txtdid.Text);

            dom.SaveChanges();
            Form2_Load(dom, e);
        }

        private void getbtn_Click(object sender, EventArgs e)
        {
            int pateintid = Convert.ToInt32(txtpid.Text);
            Patient p = dom.Patients.Find(pateintid);

            txtpname.Text = p.PatientName;
            txtpaddress.Text = p.Address;
            txtpcontact.Text = p.Contact.ToString();
            txtdid.Text = p.DoctorId.ToString();
            int docid = Convert.ToInt32(txtdid.Text);
            //Doctor d=dom.Patients.Find()
            Doctor doctor=dom.Doctors.Find(docid);
            txtdname.Text = doctor.DoctorName;
            //txtdname.Text = p.DoctorName;
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            int pateintid = Convert.ToInt32(txtpid.Text);
            Patient p = dom.Patients.Find(pateintid);
            dom.Patients.Remove(p);
            dom.SaveChanges();
            Form2_Load(dom, e);
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = (from Patient in dom.Patients where Patient.PatientName.Contains(txtpname.Text)
            select new {Patient.PatientId, Patient.PatientName, Patient.Address, Patient.Contact, Patient.DoctorId  }).ToList();

            //dataGridView1.DataSource = (from Patient in dom.Patients select new {Patient.PatientId,Patient.PatientName,Patient.Address,
            //Patient.Contact,Patient.Doctor.DoctorId}).Where(p=>p.PatientName.Contains(txtpname.Text)||
            //p.DoctorId.ToString().Contains(txtdid.Text)).ToList();
        }
}
}
