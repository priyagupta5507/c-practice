﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalDB
{
    public partial class Form1 : Form
    {
        private DBHospitalEntity dom = new DBHospitalEntity();
        Form2 form2;
        public Form1()
        {
            InitializeComponent();
            form2 = new Form2();
        }

        private void text1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            //dataGridView1.DataSource = dom.Doctors.ToList();
            dataGridView1.DataSource = dom.Doctors.Select(a => new { a.DoctorId, a.DoctorName,a.Room}).ToList();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            Doctor doctor = new Doctor();
            doctor.DoctorName = text1.Text;
            doctor.Room = Convert.ToInt32(text2.Text);

            dom.Doctors.Add(doctor);
            dom.SaveChanges();
            //Form1_Load(dom, e);

            Form1 form1 = new Form1();
            form1.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int doctorid = Convert.ToInt32(text3.Text);

            Doctor d = dom.Doctors.Find(doctorid);
            d.DoctorName = text1.Text;
            d.Room = Convert.ToInt32(text2.Text);
            dom.SaveChanges();
            Form1_Load(dom, e);

        }

        private void btnfindid_Click(object sender, EventArgs e)
        {
            int doctorid = Convert.ToInt32(text3.Text);
            Doctor d = dom.Doctors.Find(doctorid);
           
            text1.Text = d.DoctorName;
           text2.Text = d.Room.ToString();

            //int room= Convert.ToInt32(text2.Text);
            //room = d.Room;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int doctorid = Convert.ToInt32(text3.Text);
            Doctor d = dom.Doctors.Find(doctorid);
            dom.Doctors.Remove(d);
            dom.SaveChanges();
            Form1_Load(dom,e);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = (from Doctor in dom.Doctors where Doctor.DoctorName.Contains(text1.Text) select new { Doctor.DoctorId, Doctor.DoctorName, Doctor.Room }).ToList();
        }

        private void btnform2_Click(object sender, EventArgs e)
        {
            form2.Show();
        }

        //private void btn
    }
}
